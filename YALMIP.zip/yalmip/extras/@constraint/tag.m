function F = tag(F,t)

F = tag(lmi(F),t);
