function yesno = is(X,this)

yesno = is(lmi(X),this);
