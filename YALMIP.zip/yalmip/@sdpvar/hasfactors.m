function yes = hasfactors(X)

yes = length(X.midfactors)>0;
